package de.besensmp.besencore;

import io.papermc.paper.chat.ChatRenderer;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import io.papermc.paper.scoreboard.numbers.NumberFormat;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class BesenChatScoreboard extends JavaPlugin implements Listener {
    private LuckPerms luckPerms;
    private final LegacyComponentSerializer legacy = LegacyComponentSerializer.legacyAmpersand();
    private final PlainTextComponentSerializer plain = PlainTextComponentSerializer.plainText();
    private final List<String> rawLines = new ArrayList<>();
    private final Map<String, List<int[]>> rankGradients = new HashMap<>();
    private int taskId = -1;
    private String title;
    private boolean titleBold;
    private List<int[]> titleGradient = new ArrayList<>();
    private boolean useRankColors;
    private boolean hideFly;
    private boolean fancyPanel;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        setupLuckPerms();
        loadSettings();
        getServer().getPluginManager().registerEvents(this, this);

        if (getCommand("besenscoreboard") != null) {
            getCommand("besenscoreboard").setExecutor((sender, command, label, args) -> {
                if (!sender.hasPermission("besenscoreboard.admin")) {
                    sender.sendMessage(color("&cKeine Berechtigung."));
                    return true;
                }
                if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
                    reloadConfig();
                    setupLuckPerms();
                    loadSettings();
                    for (Player player : Bukkit.getOnlinePlayers()) update(player);
                    sender.sendMessage(color("&aBesenChatScoreboard wurde neu geladen."));
                    return true;
                }
                sender.sendMessage(color("&e/besenscoreboard reload"));
                return true;
            });
        }

        startTask();
        getLogger().info("BesenChatScoreboard 2.2.2 aktiviert - Chat + Scoreboard kombiniert.");
    }

    private void setupLuckPerms() {
        try {
            luckPerms = LuckPermsProvider.get();
            getLogger().info("LuckPerms gefunden - gemeinsame Rangfarben aktiv.");
        } catch (IllegalStateException ex) {
            luckPerms = null;
            getLogger().warning("LuckPerms nicht gefunden. Standardfarbe wird verwendet.");
        }
    }

    private void loadSettings() {
        title = getConfig().getString("settings.title", "BESEN SMP");
        titleBold = getConfig().getBoolean("settings.title-bold", false);
        useRankColors = getConfig().getBoolean("settings.use-rank-colors", true);
        titleGradient = loadGradient(getConfig().getStringList("settings.title-gradient"));
        hideFly = getConfig().getBoolean("settings.hide-fly-when-inactive", true);
        fancyPanel = getConfig().getBoolean("settings.fancy-panel.enabled", true);
        rawLines.clear();
        rawLines.addAll(getConfig().getStringList("lines"));
        loadRankGradients();
    }

    private void loadRankGradients() {
        rankGradients.clear();
        for (String group : getConfig().getConfigurationSection("groups").getKeys(false)) {
            List<String> colors = getConfig().getStringList("groups." + group + ".message-colors");
            if (!colors.isEmpty()) rankGradients.put(group.toLowerCase(Locale.ROOT), loadGradient(colors));
        }
    }

    private List<int[]> loadGradient(List<String> values) {
        List<int[]> result = new ArrayList<>();
        for (String value : values) {
            int[] rgb = parseHex(value);
            if (rgb != null) result.add(rgb);
        }
        if (result.isEmpty()) {
            result.add(new int[]{75, 0, 130});
            result.add(new int[]{225, 190, 231});
            result.add(new int[]{75, 0, 130});
        }
        return result;
    }

    private int[] parseHex(String value) {
        if (value == null) return null;
        String s = value.trim().replace("#", "");
        if (s.length() != 6) return null;
        try {
            return new int[]{
                    Integer.parseInt(s.substring(0, 2), 16),
                    Integer.parseInt(s.substring(2, 4), 16),
                    Integer.parseInt(s.substring(4, 6), 16)
            };
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private String getDisplayGroup(Player player) {
        if (luckPerms == null) return "default";
        try {
            var user = luckPerms.getPlayerAdapter(Player.class).getUser(player);
            for (String rank : getConfig().getStringList("rank-order")) {
                String wanted = rank.toLowerCase(Locale.ROOT);
                for (var group : user.getInheritedGroups(user.getQueryOptions())) {
                    if (group.getName().equalsIgnoreCase(wanted)) return wanted;
                }
            }
            String primary = user.getPrimaryGroup();
            return primary == null ? "default" : primary.toLowerCase(Locale.ROOT);
        } catch (Exception ignored) {
            return "default";
        }
    }

    private String getRankPrefix(Player player, String displayGroup) {
        if (luckPerms == null) return "";
        try {
            var user = luckPerms.getPlayerAdapter(Player.class).getUser(player);
            for (var group : user.getInheritedGroups(user.getQueryOptions())) {
                if (group.getName().equalsIgnoreCase(displayGroup)) {
                    String p = group.getCachedData().getMetaData().getPrefix();
                    if (p != null) return p;
                }
            }
            String p = luckPerms.getPlayerAdapter(Player.class).getMetaData(player).getPrefix();
            return p == null ? "" : p;
        } catch (Exception ignored) {
            return "";
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onChat(AsyncChatEvent event) {
        event.renderer(new RankChatRenderer(event.getPlayer()));
    }

    private final class RankChatRenderer implements ChatRenderer {
        private final Player player;
        private final String color;
        private final String emoji;
        private final String prefix;
        private final List<String> messageColors;

        private RankChatRenderer(Player player) {
            this.player = player;
            String group = getDisplayGroup(player);
            String path = "groups." + group;
            color = getConfig().getString(path + ".color", getConfig().getString("default-color", "&7"));
            emoji = getConfig().getString(path + ".emoji", getConfig().getString("default-emoji", "🙂"));
            messageColors = getConfig().getStringList(path + ".message-colors");
            prefix = getRankPrefix(player, group);
        }

        @Override
        public Component render(Player source, Component sourceDisplayName, Component message, net.kyori.adventure.audience.Audience viewer) {
            Component rank = prefix.isEmpty() ? Component.empty() : legacy.deserialize("&l" + prefix);
            Component name = legacy.deserialize("&l" + color + player.getName());
            Component nameEmoji = Component.text(" " + emoji);
            Component separator = legacy.deserialize(getConfig().getString("separator", "&8: "));
            Component coloredMessage = createGradientMessage(plain.serialize(message));
            return rank.append(name).append(nameEmoji).append(separator).append(coloredMessage);
        }

        private Component createGradientMessage(String text) {
            if (text.isEmpty()) return Component.empty();
            List<String> colors = messageColors == null || messageColors.isEmpty() ? List.of(color) : messageColors;
            Component result = Component.empty();
            int index = 0;
            for (int offset = 0; offset < text.length();) {
                int cp = text.codePointAt(offset);
                String character = new String(Character.toChars(cp));
                String c = colors.get(index % colors.size());
                Component part = Component.text(character).decorate(net.kyori.adventure.text.format.TextDecoration.BOLD);
                if (c != null && c.matches("#[0-9a-fA-F]{6}")) {
                    TextColor hex = TextColor.fromHexString(c);
                    if (hex != null) part = part.color(hex);
                } else {
                    part = legacy.deserialize(c + "&l" + character);
                }
                result = result.append(part);
                index++;
                offset += Character.charCount(cp);
            }
            return result;
        }
    }

    private Component buildGradientComponent(String text, List<int[]> stops, boolean bold) {
        if (text == null || text.isEmpty()) return Component.empty();
        int visible = 0;
        for (int i = 0; i < text.length(); i++) if (!Character.isWhitespace(text.charAt(i))) visible++;
        if (visible == 0) return Component.text(text);
        Component out = Component.empty();
        int position = 0;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (Character.isWhitespace(c)) {
                out = out.append(Component.text(String.valueOf(c)));
                continue;
            }
            double t = visible == 1 ? 0.0 : (double) position / (visible - 1);
            int[] rgb = gradientAt(stops, t);
            out = out.append(Component.text(String.valueOf(c))
                    .color(TextColor.color(rgb[0], rgb[1], rgb[2]))
                    .decoration(net.kyori.adventure.text.format.TextDecoration.BOLD, bold));
            position++;
        }
        return out;
    }

    private int[] gradientAt(List<int[]> stops, double t) {
        if (stops.size() == 1) return stops.get(0);
        t = Math.max(0.0, Math.min(1.0, t));
        double scaled = t * (stops.size() - 1);
        int index = Math.min(stops.size() - 2, (int) Math.floor(scaled));
        double local = scaled - index;
        int[] a = stops.get(index), b = stops.get(index + 1);
        return new int[]{
                (int) Math.round(a[0] + (b[0] - a[0]) * local),
                (int) Math.round(a[1] + (b[1] - a[1]) * local),
                (int) Math.round(a[2] + (b[2] - a[2]) * local)
        };
    }

    private Component buildPlayerTitle(Player player) {
        if (fancyPanel) return Component.text("\uE000")
                .font(net.kyori.adventure.key.Key.key("minecraft", "besen"));
        if (!useRankColors) return buildGradientComponent(title, titleGradient, titleBold);
        String group = getDisplayGroup(player);
        List<int[]> gradient = rankGradients.get(group);
        if (gradient == null) gradient = rankGradients.get("default");
        if (gradient == null) gradient = titleGradient;
        return buildGradientComponent(title, gradient, titleBold);
    }

    private void startTask() {
        if (taskId != -1) Bukkit.getScheduler().cancelTask(taskId);
        long ticks = Math.max(1L, getConfig().getLong("settings.refresh-ticks", 10L));
        taskId = Bukkit.getScheduler().scheduleSyncRepeatingTask(this, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) update(player);
        }, 1L, ticks);
    }

    public void update(Player player) {
        Scoreboard board = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective obj = board.registerNewObjective("besen", "dummy", buildPlayerTitle(player));
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);
        // Hide the vanilla numeric score column (11, 10, 9, ...).
        // Paper supports a blank number format on the current server API.
        obj.numberFormat(NumberFormat.blank());
        List<String> lines = new ArrayList<>();
        for (String raw : rawLines) {
            String line = color(parsePlaceholders(player, raw));
            if (hideFly && line.toLowerCase().contains("fly:")) {
                String value = extractAfterFly(line);
                if (value.isBlank() || value.equalsIgnoreCase("nicht aktiv") || value.equalsIgnoreCase("inaktiv")
                        || value.equalsIgnoreCase("inactive") || value.equalsIgnoreCase("none") || value.equalsIgnoreCase("null")) continue;
            }
            lines.add(line);
        }
        // The sidebar title is a separate custom-font image. Add one truly
        // transparent spacer row so the first data row can never overlap the
        // title's bottom border. This is the key to the clean Hypixel-style layout.
        if (fancyPanel) lines.add(0, "");

        int score = lines.size(), unique = 0;
        if (fancyPanel) {
            for (int i = 0; i < lines.size(); i++) {
                String entry = ChatColor.COLOR_CHAR + Integer.toHexString(i & 15);
                org.bukkit.scoreboard.Team team = board.registerNewTeam("bsb" + i);
                team.addEntry(entry);
                String current = lines.get(i);
                if (ChatColor.stripColor(current).trim().isEmpty()) {
                    // First spacer: only the left/right frame, NO horizontal divider.
                    // Other configured blank rows remain the decorative divider (used before IP).
                    if (i == 0) {
                        team.prefix(fancyPrefix(i, lines.size()));
                    } else {
                        team.prefix(Component.text("\uE01A").font(net.kyori.adventure.key.Key.key("minecraft", "besen")));
                    }
                    team.suffix(Component.empty());
                } else {
                    team.prefix(fancyPrefix(i, lines.size()));
                    team.suffix(fancySuffix(replaceFancyIcons(current)));
                }
                obj.getScore(entry).setScore(score--);
            }
        } else {
            for (String line : lines) obj.getScore(line + uniqueColorSuffix(unique++)).setScore(score--);
        }
        player.setScoreboard(board);
    }


    private Component fancyPrefix(int index, int totalLines) {
        int codePoint;
        if (index == totalLines - 1) codePoint = 0xE003;
        else codePoint = 0xE002;
        String value = String.valueOf((char) codePoint) + "\uE004";
        return Component.text(value)
                .font(net.kyori.adventure.key.Key.key("minecraft", "besen"));
    }

    private Component fancySuffix(String content) {
        if (content == null || content.isEmpty()) return Component.empty();
        // Normal text must use Minecraft's normal font. Only the custom icon glyphs
        // use the Besen font; otherwise every normal letter becomes a missing-glyph box.
        final String[] iconChars = {"\uE010", "\uE011", "\uE012", "\uE013", "\uE014", "\uE015", "\uE016", "\uE017", "\uE018", "\uE019"};
        Component result = Component.empty();
        int pos = 0;
        while (pos < content.length()) {
            int next = -1;
            String nextIcon = null;
            for (String icon : iconChars) {
                int at = content.indexOf(icon, pos);
                if (at >= 0 && (next < 0 || at < next)) {
                    next = at;
                    nextIcon = icon;
                }
            }
            if (next < 0) {
                result = result.append(legacy.deserialize(content.substring(pos)));
                break;
            }
            if (next > pos) result = result.append(legacy.deserialize(content.substring(pos, next)));
            result = result.append(Component.text(nextIcon).font(net.kyori.adventure.key.Key.key("minecraft", "besen")));
            pos = next + nextIcon.length();
        }
        return result;
    }

    private String replaceFancyIcons(String content) {
        if (content == null) return "";
        return content
                .replace("👑", "\uE010 ")
                .replace("🧹", "\uE011 ")
                .replace("💰", "\uE012 ")
                .replace("⭐", "\uE013 ")
                .replace("⚔", "\uE014 ")
                .replace("☠", "\uE015 ")
                .replace("⏱", "\uE016 ")
                .replace("📶", "\uE017 ")
                .replace("🪽", "\uE018 ")
                .replace("📸", "\uE013 ")
                .replace("🌐", "\uE019 ");
    }

    private String parsePlaceholders(Player player, String text) {
        // Built-in ping placeholder: no PlaceholderAPI expansion is required.
        text = text.replace("%player_ping%", String.valueOf(player.getPing()));
        if (!Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI")) return text;
        try {
            Class<?> papi = Class.forName("me.clip.placeholderapi.PlaceholderAPI");
            Method method = papi.getMethod("setPlaceholders", Player.class, String.class);
            Object result = method.invoke(null, player, text);
            return result instanceof String ? (String) result : text;
        } catch (ReflectiveOperationException ignored) {
            return text;
        }
    }

    private String uniqueColorSuffix(int index) {
        int value = index;
        StringBuilder suffix = new StringBuilder();
        do {
            suffix.append(ChatColor.COLOR_CHAR).append(Integer.toHexString(value & 15));
            value >>= 4;
        } while (value > 0);
        return suffix.toString();
    }

    private String extractAfterFly(String line) {
        int i = line.toLowerCase().indexOf("fly:");
        return i < 0 ? "" : ChatColor.stripColor(line.substring(i + 4)).trim();
    }

    private String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s == null ? "" : s);
    }

    @Override
    public void onDisable() {
        if (taskId != -1) Bukkit.getScheduler().cancelTask(taskId);
    }
}
