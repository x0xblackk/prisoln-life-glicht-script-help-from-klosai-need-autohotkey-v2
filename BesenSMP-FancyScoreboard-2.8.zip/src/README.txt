BesenChatScoreboard 2.0.0
=========================

Kombiniert:
- BesenChat 1.1.3 Funktionen
- BesenScoreboard 1.0.6 Funktionen
- EIN gemeinsamer Rang-/Farbverlauf aus groups.*.message-colors
- Scoreboard-Titel passt sich über rank-order an den aktiven Rang an
- Cleaner RGB-Verlauf, nicht fett
- /besenscoreboard reload

INSTALLATION
1. Alte BesenChat.jar und alte BesenScoreboard.jar aus plugins entfernen.
2. BesenChatScoreboard.jar nach plugins kopieren.
3. Server komplett neu starten.
4. Falls du die Config anpassen willst: plugins/BesenChatScoreboard/config.yml
5. Nach Config-Änderungen: /besenscoreboard reload

WICHTIG
Nicht gleichzeitig BesenChat und BesenScoreboard mit diesem Plugin laufen lassen,
sonst greifen zwei Plugins auf Chat/Scoreboard zu.

BUILD
Im Projektordner:
& "C:\Users\Anwender\Downloads\apache-maven-3.9.16-bin\apache-maven-3.9.16\bin\mvn.cmd" clean package

Die fertige JAR liegt danach in target/.


FANCY SCOREBOARD
- Requires BesenSMP-Scoreboard-ResourcePack.zip on the client.
- config.yml has settings.fancy-panel.enabled=true.
- The plugin uses private-use font glyphs U+E000..U+E00C and U+E100/U+E101.
- Install the resource pack as the server resource pack or let players apply it manually.

2.2.3: slimmer 160px panel and refined pixel-art icons. Resource pack 2.7.
